import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PencilLine, c as AlarmClockOff, i as Ruler, n as Tag, o as ChevronDown, r as Send, s as Ban } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dgn414q3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbwrEXQZX7yiFjcg20qI_lC_uRUs8a61GEEmnarGky2G-vx1330v2uf4OwwQVDdCz5gm/exec";
var GUIDE_PDF_URL = "PASTE_GOOGLE_DRIVE_PDF_LINK";
var TELEGRAM_URL = "PASTE_TELEGRAM_GROUP_LINK";
var PRIVACY_URL = "PASTE_PRIVACY_DOC_LINK";
var SCREENSHOT_1 = "/panels/risk.jpg";
var SCREENSHOT_2 = "";
var SCREENSHOT_3 = "/panels/exit.png";
var SCREENSHOT_4 = "/panels/time.jpg";
var SESSIONS = [
	"Thu 15 Oct, 8:30 pm",
	"Sun 18 Oct, 11:00 am",
	"Both"
];
var PHONE_RE = /^[6-9]\d{9}$/;
var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
var GATES = [
	{
		name: "Market direction",
		pass: true
	},
	{
		name: "Stock trend",
		pass: true
	},
	{
		name: "Momentum",
		pass: true
	},
	{
		name: "Volume",
		pass: false
	},
	{
		name: "Price location",
		pass: true
	},
	{
		name: "Risk",
		pass: true
	},
	{
		name: "Time",
		pass: true
	}
];
var CONDITIONS = [
	["Market direction", "Is the overall market moving my way today?"],
	["Stock trend", "Is this stock itself trending in my direction?"],
	["Momentum", "Is the move strong, but not already exhausted?"],
	["Volume", "Is real money behind the move, and can I exit easily?"],
	["Price location", "Is price at an important level, with a strong closed candle?"],
	["Risk", "Does this trade fit my risk per trade, maximum position size and maximum loss per day?"],
	["Time", "Is this the right time of day for this trade?"]
];
var AGENDA = [
	["0–10 min", "Why most traders lose: the math"],
	["10–25 min", "The 7 conditions, explained on a chart more than 30 days old"],
	["25–40 min", "Position size and risk per trade with a formula"],
	["40–50 min", "Maximum loss per day: the rule that protects your capital"],
	["50–60 min", "How one-tap automation works behind the scenes"],
	["+ 20 min", "Live Q&A"]
];
var FAQ = [
	["Is it really free?", "Yes. The masterclass and the guide are free."],
	["Why is it free?", "It's an introduction. At the end we'll briefly mention our paid course for those who want to build the full system; there's no obligation."],
	["Where does it happen?", "Live on Telegram. The group link appears after you register; the live link is posted there 30 minutes before."],
	["Will you give stock tips?", "No. Education only: no buy/sell calls."],
	["Do I need coding knowledge?", "No. This session is about rules, math and risk."],
	["What language?", "Hindi and English mixed."]
];
var SHOTS = [
	{
		src: SCREENSHOT_1,
		fit: "cover",
		caption: "Risk settings: risk per trade, maximum position size, maximum loss per day"
	},
	{
		src: SCREENSHOT_2,
		fit: "cover",
		caption: "Entry conditions: each one switches on or off"
	},
	{
		src: SCREENSHOT_3,
		fit: "cover",
		caption: "Exit settings: stop-loss, trailing stop, partial booking"
	},
	{
		src: SCREENSHOT_4,
		fit: "contain",
		caption: "Time settings: entry window and square-off time"
	}
].filter((shot) => shot.src);
function nationalDigits(value) {
	return value.replace(/[\s-]/g, "");
}
function firstNameOf(full) {
	return full.trim().split(/\s+/)[0] ?? full.trim();
}
function validate(form) {
	const errors = {};
	if (!form.name.trim()) errors.name = "Enter your full name.";
	if (!PHONE_RE.test(nationalDigits(form.phone))) errors.phone = "Enter a 10-digit mobile number starting with 6, 7, 8 or 9.";
	const whatsapp = nationalDigits(form.whatsapp);
	if (whatsapp && !PHONE_RE.test(whatsapp)) errors.whatsapp = "Enter a 10-digit mobile number starting with 6, 7, 8 or 9, or leave this blank.";
	if (!EMAIL_RE.test(form.email.trim())) errors.email = "Enter a valid email address.";
	if (!form.session) errors.session = "Choose a session.";
	if (!form.consent) errors.consent = "Tick the box to agree to be contacted about this masterclass.";
	return errors;
}
function linkProps(url) {
	if (url.startsWith("http://") || url.startsWith("https://")) return {
		href: url,
		target: "_blank",
		rel: "noopener noreferrer"
	};
	return { href: url };
}
function readUtm() {
	const params = new URLSearchParams(window.location.search);
	return {
		utm_source: (params.get("utm_source") ?? "").trim(),
		utm_campaign: (params.get("utm_campaign") ?? "").trim()
	};
}
function Home() {
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [whatsapp, setWhatsapp] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [session, setSession] = (0, import_react.useState)("");
	const [consent, setConsent] = (0, import_react.useState)(false);
	const [showErrors, setShowErrors] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [registered, setRegistered] = (0, import_react.useState)("");
	const [showBar, setShowBar] = (0, import_react.useState)(false);
	const [openShot, setOpenShot] = (0, import_react.useState)(null);
	const errors = showErrors ? validate({
		name,
		phone,
		whatsapp,
		email,
		session,
		consent
	}) : {};
	(0, import_react.useEffect)(() => {
		const hero = document.getElementById("hero");
		if (!hero) return;
		const observer = new IntersectionObserver(([entry]) => setShowBar(!entry.isIntersecting), { threshold: 0 });
		observer.observe(hero);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!registered) return;
		document.getElementById("success-title")?.focus();
	}, [registered]);
	(0, import_react.useEffect)(() => {
		if (!openShot) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpenShot(null);
		};
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		document.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = previous;
			document.removeEventListener("keydown", onKey);
		};
	}, [openShot]);
	async function onSubmit(event) {
		event.preventDefault();
		if (pending) return;
		const next = validate({
			name,
			phone,
			whatsapp,
			email,
			session,
			consent
		});
		setShowErrors(true);
		if (Object.keys(next).length > 0) {
			const first = [
				"name",
				"phone",
				"whatsapp",
				"email",
				"session",
				"consent"
			].find((key) => next[key]);
			if (first) document.getElementById(first)?.focus();
			return;
		}
		const utm = readUtm();
		const phoneDigits = nationalDigits(phone);
		const whatsappDigits = nationalDigits(whatsapp);
		const data = {
			name: name.trim(),
			phone: `+91${phoneDigits}`,
			whatsapp: whatsappDigits ? `+91${whatsappDigits}` : "",
			email: email.trim(),
			session,
			consent: true,
			source: "landing_page",
			utm_source: utm.utm_source,
			utm_campaign: utm.utm_campaign
		};
		setPending(true);
		try {
			await fetch(WEBHOOK_URL, {
				method: "POST",
				mode: "no-cors",
				headers: { "Content-Type": "text/plain;charset=utf-8" },
				body: JSON.stringify(data)
			});
		} catch (err) {
			console.error("Registration webhook failed", err);
		}
		setRegistered(firstNameOf(name));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#register",
			className: "sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:bg-accent focus:px-4 focus:py-3 focus:font-semibold focus:text-ink",
			children: "Skip to registration"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "z-30 bg-ink md:sticky md:top-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-semibold text-paper sm:text-base",
					children: "FiNARTHiS Academy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#register",
					className: "hidden min-h-11 items-center bg-accent px-4 text-sm font-semibold text-ink md:inline-flex",
					children: "Register free"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "hero",
				className: "bg-ink text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-5xl items-center gap-10 px-5 py-12 sm:px-8 sm:py-20 lg:grid-cols-[1.1fr_0.9fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-accent uppercase",
							children: "Free live masterclass · 60 min + Q&A"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-xl text-4xl font-semibold text-paper sm:text-5xl",
							children: "Trading is not an art. It's math."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-base leading-relaxed text-paper sm:text-lg",
							children: "Learn the 7 conditions every trade must pass, how to size a position with a formula, and the daily loss limit that protects your capital — then how to automate it all with one tap."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "border border-edge bg-panel px-4 py-3 font-mono text-sm text-paper",
								children: "Thu 15 Oct · 8:30 pm IST"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "border border-edge bg-panel px-4 py-3 font-mono text-sm text-paper",
								children: "Sun 18 Oct · 11:00 am IST"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#register",
							className: "mt-6 inline-flex min-h-12 w-full items-center justify-center bg-accent px-6 text-base font-semibold text-ink sm:w-auto",
							children: "Reserve my free seat"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 flex flex-col gap-2 text-sm text-paper-soft sm:flex-row sm:flex-wrap sm:gap-x-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
										className: "size-5 shrink-0 text-accent",
										"aria-hidden": "true",
										strokeWidth: 1.75
									}), "Free"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
										className: "size-5 shrink-0 text-accent",
										"aria-hidden": "true",
										strokeWidth: 1.75
									}), "Live on Telegram"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, {
										className: "size-5 shrink-0 text-accent",
										"aria-hidden": "true",
										strokeWidth: 1.75
									}), "Education only, no tips"]
								})
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeFilter, {})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-2xl text-3xl font-semibold text-ink sm:text-4xl",
							children: "Still in loss after trying everything?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 max-w-2xl space-y-4 text-base leading-relaxed text-body",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You followed tips. You joined courses. You copied what every advisor and mentor said. And the account is still red. You're not alone — SEBI's own study found about 9 in 10 individual F&O traders lost money." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The problem is rarely the advice. It's that nobody showed you the math behind a trade: when to take it, how big it should be, and when to stop for the day." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If you're ready to stop guessing and start trading by rules you can measure, you're at the right place at the right time." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-8 grid gap-4 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pain, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PencilLine, {
										className: "size-5",
										"aria-hidden": "true",
										strokeWidth: 1.75
									}),
									text: "Entries on gut feeling"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pain, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ruler, {
										className: "size-5",
										"aria-hidden": "true",
										strokeWidth: 1.75
									}),
									text: "Position size by mood"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pain, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlarmClockOff, {
										className: "size-5",
										"aria-hidden": "true",
										strokeWidth: 1.75
									}),
									text: "No rule to stop after a bad morning"
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-2xl text-3xl font-semibold text-ink sm:text-4xl",
							children: "Trading is math. Here's how."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Formula, {
									n: "01",
									title: "Your edge is a number.",
									formula: "Edge per trade = (Win rate × Average win) − (Loss rate × Average loss) − Costs",
									example: "Example (illustration only): Win 40% at ₹1,500, lose 60% at ₹800, costs ₹150 per trade →",
									worked: "0.40 × 1,500 − 0.60 × 800 − 150 = −₹30 per trade.",
									caption: "Feels like a good system. Still loses money. You can only fix what you measure."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Formula, {
									n: "02",
									title: "Position size is a formula, not a feeling.",
									formula: "Quantity = Money you can afford to lose on this trade ÷ Distance to stop-loss",
									example: "Example: ₹5,000 risk ÷ ₹5 stop distance = 1,000 shares.",
									caption: "Same risk on every trade. No more one big loss wiping out ten wins."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Formula, {
									n: "03",
									title: "A daily loss limit is a rule, not hope.",
									formula: "If today's loss ≥ maximum loss per day → no more trades today.",
									caption: "One bad morning stays one bad morning."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-muted",
							children: "All numbers are illustrations for learning, not results or recommendations."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-3xl text-3xl font-semibold text-ink sm:text-4xl",
							children: "The 7 conditions every trade must pass"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base leading-relaxed text-body",
							children: "A trade is taken only when all 7 are true. If even one is false, there is no trade."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-8 max-w-3xl border-t border-line",
							children: CONDITIONS.map(([title, line], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid grid-cols-[2.5rem_1fr] gap-3 border-b border-line py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm font-medium text-accent",
									children: String(index + 1).padStart(2, "0")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-base leading-relaxed text-body",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display font-semibold text-ink",
											children: title
										}),
										" — ",
										line
									]
								})]
							}, title))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-ink text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-2xl text-3xl font-semibold text-paper sm:text-4xl",
							children: "Rules you can see, not a black box."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base leading-relaxed text-paper",
							children: "This is the actual settings panel of the FMTS framework we teach from. Every condition and every risk limit is a setting you can see and change."
						}),
						SHOTS.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 md:grid md:grid-cols-2 md:overflow-visible",
							children: SHOTS.map((shot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "w-[85%] shrink-0 snap-start md:w-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setOpenShot(shot),
									className: "block w-full border border-edge bg-panel text-left",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: shot.src,
										alt: shot.caption,
										className: shot.fit === "contain" ? "h-auto w-full object-contain" : "h-72 w-full object-cover object-top",
										loading: "lazy"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
									className: "mt-3 text-sm leading-relaxed text-paper-soft",
									children: shot.caption
								})]
							}, shot.caption))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-paper-soft",
							children: "Settings shown for education. Not a recommendation to trade any security."
						})] }) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-2xl text-3xl font-semibold text-ink sm:text-4xl",
							children: "What happens in the 60 minutes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-8 max-w-3xl border-t border-line",
							children: AGENDA.map(([when, what]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid gap-1 border-b border-line py-4 sm:grid-cols-[8rem_1fr] sm:gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm font-medium text-ink",
									children: when
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base text-body",
									children: what
								})]
							}, when))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-base text-body",
							children: "You also get the free 7 Conditions guide (PDF) as soon as you register."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl font-semibold text-ink sm:text-4xl",
							children: "Who runs this"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-display text-xl font-semibold text-ink",
							children: "Mohan Saha · Founder, FiNARTHiS Academy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base leading-relaxed text-body",
							children: "5+ years of active trading on NSE and MCX with a deep, data-driven understanding of how markets move. 16 years as an engineer on large projects at L&T, Tata Projects and RIL — which is why everything here is built like an engineering spec: measured, tested, written down. NISM-certified."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-sm leading-relaxed text-muted",
							children: "NISM certification is a qualification, not a SEBI registration. FiNARTHiS is not a SEBI-registered investment adviser or research analyst."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "register",
				className: "scroll-mt-6 bg-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-w-xl bg-card p-5 sm:p-8",
						children: registered ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								id: "success-title",
								tabIndex: -1,
								className: "text-3xl font-semibold text-ink",
								children: [
									"You're registered, ",
									registered,
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "inline-flex min-h-12 w-full items-center justify-center bg-accent px-4 text-center text-base font-semibold text-ink",
									...linkProps(GUIDE_PDF_URL),
									children: "Download the free 7 Conditions guide"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "inline-flex min-h-12 w-full items-center justify-center border-2 border-ink px-4 text-center text-base font-semibold text-ink",
									...linkProps(TELEGRAM_URL),
									children: "Join the masterclass Telegram group"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm leading-relaxed text-body",
								children: "The live link is posted in the Telegram group 30 minutes before your session."
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit,
							noValidate: true,
							"aria-busy": pending,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-semibold text-ink",
								children: "Reserve your free seat"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										id: "name",
										label: "Full name",
										error: errors.name,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "name",
											name: "name",
											type: "text",
											autoComplete: "name",
											autoCapitalize: "words",
											maxLength: 160,
											value: name,
											onChange: (event) => setName(event.target.value),
											onBlur: () => setName((value) => value.trim()),
											"aria-invalid": errors.name ? true : void 0,
											"aria-describedby": errors.name ? "name-error" : void 0,
											className: inputClass(Boolean(errors.name))
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										id: "phone",
										label: "Contact number",
										error: errors.phone,
										hint: "India +91",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneInput, {
											id: "phone",
											name: "phone",
											value: phone,
											error: Boolean(errors.phone),
											autoComplete: "tel-national",
											onChange: setPhone
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										id: "whatsapp",
										label: "WhatsApp number, only if different from contact number",
										error: errors.whatsapp,
										optional: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneInput, {
											id: "whatsapp",
											name: "whatsapp",
											value: whatsapp,
											error: Boolean(errors.whatsapp),
											autoComplete: "tel",
											onChange: setWhatsapp
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										id: "email",
										label: "Email ID",
										error: errors.email,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "email",
											name: "email",
											type: "email",
											inputMode: "email",
											autoComplete: "email",
											autoCapitalize: "none",
											spellCheck: false,
											maxLength: 254,
											value: email,
											onChange: (event) => setEmail(event.target.value),
											onBlur: () => setEmail((value) => value.trim()),
											"aria-invalid": errors.email ? true : void 0,
											"aria-describedby": errors.email ? "email-error" : void 0,
											className: inputClass(Boolean(errors.email))
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
										"aria-invalid": errors.session ? true : void 0,
										"aria-describedby": errors.session ? "session-error" : void 0,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", {
												className: "mb-2 text-sm font-medium text-ink",
												children: [
													"Session",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														"aria-hidden": "true",
														children: " *"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "sr-only",
														children: " required"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid gap-2",
												children: SESSIONS.map((option, index) => {
													const selected = session === option;
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: `flex min-h-12 cursor-pointer items-center gap-3 border-2 px-3 ${selected ? "border-accent bg-paper" : "border-line bg-card"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															id: index === 0 ? "session" : void 0,
															type: "radio",
															name: "session",
															value: option,
															checked: selected,
															onChange: () => setSession(option)
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-base text-body",
															children: option
														})]
													}, option);
												})
											}),
											errors.session ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorText, {
												id: "session-error",
												text: errors.session
											}) : null
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "consent",
										className: "flex min-h-11 cursor-pointer items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex h-11 w-11 shrink-0 items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "consent",
												name: "consent",
												type: "checkbox",
												checked: consent,
												onChange: (event) => setConsent(event.target.checked),
												"aria-invalid": errors.consent ? true : void 0,
												"aria-describedby": errors.consent ? "consent-error" : void 0,
												className: "size-6"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "pt-2 text-sm leading-relaxed text-body",
											children: "I agree that FiNARTHiS Academy may contact me on WhatsApp, phone and email about this masterclass and its courses. I can opt out any time by replying STOP."
										})]
									}), errors.consent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorText, {
										id: "consent-error",
										text: errors.consent
									}) : null] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										disabled: pending,
										"aria-busy": pending,
										className: "inline-flex min-h-12 w-full items-center justify-center bg-accent px-4 text-base font-semibold text-ink disabled:opacity-60",
										children: "Register free"
									})
								]
							})]
						})
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-3xl font-semibold text-ink sm:text-4xl",
						children: "FAQ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 max-w-3xl border-t border-line",
						children: FAQ.map(([question, answer]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "border-b border-line",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
								className: "flex min-h-12 items-center justify-between gap-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base font-semibold text-ink",
									children: question
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
									className: "chevron size-5 shrink-0 text-ink",
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pb-4 text-base leading-relaxed text-body",
								children: answer
							})]
						}, question))
					})]
				})
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: "bg-ink pb-28 text-paper md:pb-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-5 py-12 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-semibold",
						children: "FiNARTHiS Academy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "mailto:finarthis@gmail.com",
							className: "inline-flex min-h-11 items-center underline decoration-accent underline-offset-4",
							children: "finarthis@gmail.com"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://wa.me/918980908278",
						className: "inline-flex min-h-11 items-center underline decoration-accent underline-offset-4",
						target: "_blank",
						rel: "noopener noreferrer",
						children: "+91 8980908278"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-3xl text-xs leading-relaxed text-paper-soft",
						children: "Educational content only. Not investment advice. FiNARTHiS Academy does not provide investment advice, research recommendations, trading signals or any service requiring SEBI registration. FiNARTHiS and its founder are not registered with SEBI as an investment adviser or research analyst. All market examples use price data at least 30 days old. No claims are made about past or future performance. Most retail traders in intraday and derivatives segments lose money."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "inline-flex min-h-11 items-center text-sm underline decoration-accent underline-offset-4",
							...linkProps(PRIVACY_URL),
							children: "Privacy"
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `mobile-cta fixed inset-x-0 bottom-0 z-40 border-t border-edge bg-ink p-3 transition-transform duration-200 md:hidden ${showBar ? "translate-y-0" : "pointer-events-none translate-y-full"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#register",
				className: "inline-flex min-h-12 w-full items-center justify-center bg-accent px-4 text-base font-semibold text-ink",
				children: "Register free"
			})
		}),
		openShot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-50 flex flex-col bg-ink p-4",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": openShot.caption,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpenShot(null),
						className: "inline-flex min-h-11 items-center bg-accent px-4 text-sm font-semibold text-ink",
						children: "Close"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 flex min-h-0 flex-1 items-center justify-center",
					onClick: () => setOpenShot(null),
					"aria-label": "Close settings image",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: openShot.src,
						alt: openShot.caption,
						className: "max-h-full max-w-full object-contain"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-3 text-sm text-paper-soft",
					children: openShot.caption
				})
			]
		}) : null
	] });
}
function TradeFilter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-edge bg-card p-4 text-ink sm:p-5",
		"aria-label": "A signal passes seven conditions. If one fails, there is no trade. If all pass, the trade is allowed.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs font-medium tracking-widest text-muted uppercase",
				children: "Signal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-3 grid gap-2",
				children: GATES.map((gate, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 border border-line px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-body",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-muted",
								children: index + 1
							}),
							" ",
							gate.name
						]
					}), gate.pass ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 20 20",
						className: "size-5 shrink-0 text-accent",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M4 10.5 8 14.5 16 6",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2"
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 20 20",
						className: "size-5 shrink-0 text-fail",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M5 5l10 10M15 5 5 15",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2"
						})
					})]
				}), gate.pass ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 ml-6 border border-line bg-paper px-3 py-2 text-sm text-muted",
					children: "No trade"
				})] }, gate.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 bg-accent px-3 py-3 text-center font-display text-base font-semibold text-ink",
				children: "Trade allowed"
			})
		]
	});
}
function Pain({ icon, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 border border-line bg-card p-4 text-base text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-ink",
			children: icon
		}), text]
	});
}
function Formula({ n, title, formula, example, worked, caption }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "border border-line p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-sm font-medium text-accent",
				children: n
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 text-xl font-semibold text-ink",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-mono text-sm leading-relaxed text-ink sm:text-base",
				children: formula
			}),
			example ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base leading-relaxed text-body",
				children: example
			}) : null,
			worked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-sm leading-relaxed text-ink sm:text-base",
				children: worked
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base leading-relaxed text-body",
				children: caption
			})
		]
	});
}
function inputClass(invalid) {
	return `min-h-12 w-full border bg-card px-3 text-base text-body ${invalid ? "border-ink" : "border-line"}`;
}
function ErrorText({ id, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		id,
		role: "alert",
		className: "mt-2 text-sm font-medium text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Error: "
		}), text]
	});
}
function Field({ id, label, error, optional, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			htmlFor: id,
			className: "mb-2 block text-sm font-medium text-ink",
			children: [label, optional ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				children: " *"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "sr-only",
				children: [" required", hint ? `, ${hint}` : ""]
			})] })]
		}),
		children,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorText, {
			id: `${id}-error`,
			text: error
		}) : null
	] });
}
function PhoneInput({ id, name, value, error, autoComplete, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `phone-field flex min-h-12 border bg-card ${error ? "border-ink" : "border-line"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex items-center border-r border-line px-3 text-base font-medium text-ink",
			"aria-hidden": "true",
			children: "+91"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			name,
			type: "tel",
			inputMode: "numeric",
			autoComplete,
			autoCapitalize: "none",
			spellCheck: false,
			value,
			onChange: (event) => onChange(event.target.value),
			onBlur: () => onChange(nationalDigits(value)),
			"aria-invalid": error ? true : void 0,
			"aria-describedby": error ? `${id}-error` : void 0,
			className: "min-h-12 w-full bg-transparent px-3 text-base text-body"
		})]
	});
}
//#endregion
export { Home as component };
