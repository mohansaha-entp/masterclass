//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DMPYLUTo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DL5RcBBH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DL5RcBBH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CReqMkDF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
