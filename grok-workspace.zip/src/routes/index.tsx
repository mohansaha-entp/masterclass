import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AlarmClockOff, Ban, ChevronDown, PencilLine, Ruler, Send, Tag } from "lucide-react";

// Edit these before you share the page. Leave a screenshot blank to hide that slide.
const WEBHOOK_URL =
  "https://script.google.com/macros/s/AKfycbwrEXQZX7yiFjcg20qI_lC_uRUs8a61GEEmnarGky2G-vx1330v2uf4OwwQVDdCz5gm/exec";
const GUIDE_PDF_URL =
  "https://drive.google.com/file/d/1mbPSpkvKD8p25ljOtV8zW7k5pkG6DRbg/view?usp=drivesdk";
const TELEGRAM_URL = "PASTE_TELEGRAM_GROUP_LINK";
const PRIVACY_URL = "PASTE_PRIVACY_DOC_LINK";
const SCREENSHOT_1 = "/panels/risk.jpg";
const SCREENSHOT_2 = "";
const SCREENSHOT_3 = "/panels/exit.png";
const SCREENSHOT_4 = "/panels/time.jpg";

const SESSIONS = ["Thu 15 Oct, 8:30 pm", "Sun 18 Oct, 11:00 am", "Both"] as const;
type SessionChoice = (typeof SESSIONS)[number];

type FieldErrors = Partial<{
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  session: string;
  consent: string;
}>;

const PHONE_RE = /^[6-9]\d{9}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const FILTER_CONDITIONS = [
  { name: "Market direction", pass: true },
  { name: "Stock trend", pass: true },
  { name: "Momentum", pass: true },
  { name: "Volume", pass: false },
  { name: "Price location", pass: true },
  { name: "Risk", pass: true },
  { name: "Time", pass: true },
] as const;

const CONDITIONS = [
  ["Market direction", "Is the overall market moving my way today?"],
  ["Stock trend", "Is this stock itself trending in my direction?"],
  ["Momentum", "Is the move strong, but not already exhausted?"],
  ["Volume", "Is real money behind the move, and can I exit easily?"],
  ["Price location", "Is price at an important level, with a strong closed candle?"],
  ["Risk", "Does this trade fit my risk per trade, maximum position size and maximum loss per day?"],
  ["Time", "Is this the right time of day for this trade?"],
] as const;

const AGENDA = [
  ["0–10 min", "Why most traders lose: the math"],
  ["10–25 min", "The 7 conditions, explained on a chart more than 30 days old"],
  ["25–40 min", "Position size and risk per trade with a formula"],
  ["40–50 min", "Maximum loss per day: the rule that protects your capital"],
  ["50–60 min", "How one-tap automation works behind the scenes"],
  ["+ 20 min", "Live Q&A"],
] as const;

const FAQ = [
  ["Is it really free?", "Yes. The masterclass and the guide are free."],
  [
    "Why is it free?",
    "It's an introduction. At the end we'll briefly mention our paid course for those who want to build the full system; there's no obligation.",
  ],
  [
    "Where does it happen?",
    "Live on Telegram. The group link appears after you register; the live link is posted there 30 minutes before.",
  ],
  ["Will you give stock tips?", "No. Education only: no buy/sell calls."],
  ["Do I need coding knowledge?", "No. This session is about rules, math and risk."],
  ["What language?", "Hindi and English mixed."],
] as const;

const SHOTS = [
  {
    src: SCREENSHOT_1,
    fit: "cover" as const,
    caption: "Risk settings: risk per trade, maximum position size, maximum loss per day",
  },
  {
    src: SCREENSHOT_2,
    fit: "cover" as const,
    caption: "Entry conditions: each one switches on or off",
  },
  {
    src: SCREENSHOT_3,
    fit: "cover" as const,
    caption: "Exit settings: stop-loss, trailing stop, partial booking",
  },
  {
    src: SCREENSHOT_4,
    fit: "contain" as const,
    caption: "Time settings: entry window and square-off time",
  },
].filter((shot) => shot.src);

function nationalDigits(value: string): string {
  return value.replace(/[\s-]/g, "");
}

function firstNameOf(full: string): string {
  return full.trim().split(/\s+/)[0] ?? full.trim();
}

function validate(form: {
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  session: string;
  consent: boolean;
}): FieldErrors {
  const errors: FieldErrors = {};
  if (!form.name.trim()) errors.name = "Enter your full name.";
  if (!PHONE_RE.test(nationalDigits(form.phone))) {
    errors.phone = "Enter a 10-digit mobile number starting with 6, 7, 8 or 9.";
  }
  const whatsapp = nationalDigits(form.whatsapp);
  if (whatsapp && !PHONE_RE.test(whatsapp)) {
    errors.whatsapp =
      "Enter a 10-digit mobile number starting with 6, 7, 8 or 9, or leave this blank.";
  }
  if (!EMAIL_RE.test(form.email.trim())) errors.email = "Enter a valid email address.";
  if (!form.session) errors.session = "Choose a session.";
  if (!form.consent) {
    errors.consent = "Tick the box to agree to be contacted about this masterclass.";
  }
  return errors;
}

function linkProps(url: string) {
  if (url.startsWith("http://") || url.startsWith("https://")) {
    return { href: url, target: "_blank" as const, rel: "noopener noreferrer" };
  }
  return { href: url };
}

function readUtm() {
  const params = new URLSearchParams(window.location.search);
  return {
    utm_source: (params.get("utm_source") ?? "").trim(),
    utm_campaign: (params.get("utm_campaign") ?? "").trim(),
  };
}

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [email, setEmail] = useState("");
  const [session, setSession] = useState<SessionChoice | "">("");
  const [consent, setConsent] = useState(false);
  const [showErrors, setShowErrors] = useState(false);
  const [pending, setPending] = useState(false);
  const [registered, setRegistered] = useState("");
  const [showBar, setShowBar] = useState(false);
  const [openShot, setOpenShot] = useState<(typeof SHOTS)[number] | null>(null);

  const errors = showErrors
    ? validate({ name, phone, whatsapp, email, session, consent })
    : {};

  useEffect(() => {
    const hero = document.getElementById("hero");
    if (!hero) return;
    const observer = new IntersectionObserver(
      ([entry]) => setShowBar(!entry.isIntersecting),
      { threshold: 0 },
    );
    observer.observe(hero);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!registered) return;
    document.getElementById("success-title")?.focus();
  }, [registered]);

  useEffect(() => {
    if (!openShot) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpenShot(null);
    };
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", onKey);
    };
  }, [openShot]);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    const next = validate({ name, phone, whatsapp, email, session, consent });
    setShowErrors(true);
    if (Object.keys(next).length > 0) {
      const order = ["name", "phone", "whatsapp", "email", "session", "consent"] as const;
      const first = order.find((key) => next[key]);
      if (first) document.getElementById(first)?.focus();
      return;
    }

    const utm = readUtm();
    const phoneDigits = nationalDigits(phone);
    const whatsappDigits = nationalDigits(whatsapp);
    const data = {
      name: name.trim(),
      phone: `+91${phoneDigits}`,
      whatsapp: whatsappDigits ? `+91${whatsappDigits}` : "",
      email: email.trim(),
      session,
      consent: true as const,
      source: "landing_page" as const,
      utm_source: utm.utm_source,
      utm_campaign: utm.utm_campaign,
    };

    setPending(true);
    try {
      await fetch(WEBHOOK_URL, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify(data),
      });
    } catch (err) {
      console.error("Registration webhook failed", err);
    }
    setRegistered(firstNameOf(name));
  }

  return (
    <>
      <a
        href="#register"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:bg-accent focus:px-4 focus:py-3 focus:font-semibold focus:text-ink"
      >
        Skip to registration
      </a>

      <header className="z-30 bg-ink md:sticky md:top-0">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <p className="font-display text-sm font-semibold text-paper sm:text-base">
            FiNARTHiS Academy
          </p>
          <a
            href="#register"
            className="hidden min-h-11 items-center bg-accent px-4 text-sm font-semibold text-ink md:inline-flex"
          >
            Register free
          </a>
        </div>
      </header>

      <main>
        <section id="hero" className="bg-ink text-paper">
          <div className="mx-auto grid max-w-5xl items-center gap-10 px-5 py-12 sm:px-8 sm:py-20 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <p className="text-xs font-semibold tracking-widest text-accent uppercase">
                Free live masterclass · 60 min + Q&A
              </p>
              <h1 className="mt-4 max-w-xl text-4xl font-semibold text-paper sm:text-5xl">
                Trading is not an art. It's math.
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-paper sm:text-lg">
                Learn the 7 conditions every trade must pass, how to size a position
                with a formula, and the daily loss limit that protects your capital —
                then how to automate it all with one tap.
              </p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <p className="border border-edge bg-panel px-4 py-3 font-mono text-sm text-paper">
                  Thu 15 Oct · 8:30 pm IST
                </p>
                <p className="border border-edge bg-panel px-4 py-3 font-mono text-sm text-paper">
                  Sun 18 Oct · 11:00 am IST
                </p>
              </div>
              <a
                href="#register"
                className="mt-6 inline-flex min-h-12 w-full items-center justify-center bg-accent px-6 text-base font-semibold text-ink sm:w-auto"
              >
                Reserve my free seat
              </a>
              <ul className="mt-4 flex flex-col gap-2 text-sm text-paper-soft sm:flex-row sm:flex-wrap sm:gap-x-5">
                <li className="inline-flex items-center gap-2">
                  <Tag className="size-5 shrink-0 text-accent" aria-hidden="true" strokeWidth={1.75} />
                  Free
                </li>
                <li className="inline-flex items-center gap-2">
                  <Send className="size-5 shrink-0 text-accent" aria-hidden="true" strokeWidth={1.75} />
                  Live on Telegram
                </li>
                <li className="inline-flex items-center gap-2">
                  <Ban className="size-5 shrink-0 text-accent" aria-hidden="true" strokeWidth={1.75} />
                  Education only, no tips
                </li>
              </ul>
            </div>
            <TradeFilter />
          </div>
        </section>

        <section className="bg-paper">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="max-w-2xl text-3xl font-semibold text-ink sm:text-4xl">
              Still in loss after trying everything?
            </h2>
            <div className="mt-5 max-w-2xl space-y-4 text-base leading-relaxed text-body">
              <p>
                You followed tips. You joined courses. You copied what every advisor
                and mentor said. And the account is still red. You're not alone —
                SEBI's own study found about 9 in 10 individual F&O traders lost money.
              </p>
              <p>
                The problem is rarely the advice. It's that nobody showed you the math
                behind a trade: when to take it, how big it should be, and when to stop
                for the day.
              </p>
              <p>
                If you're ready to stop guessing and start trading by rules you can
                measure, you're at the right place at the right time.
              </p>
            </div>
            <ul className="mt-8 grid gap-4 sm:grid-cols-3">
              <Pain icon={<PencilLine className="size-5" aria-hidden="true" strokeWidth={1.75} />} text="Entries on gut feeling" />
              <Pain icon={<Ruler className="size-5" aria-hidden="true" strokeWidth={1.75} />} text="Position size by mood" />
              <Pain
                icon={<AlarmClockOff className="size-5" aria-hidden="true" strokeWidth={1.75} />}
                text="No rule to stop after a bad morning"
              />
            </ul>
          </div>
        </section>

        <section className="bg-card">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="max-w-2xl text-3xl font-semibold text-ink sm:text-4xl">
              Trading is math. Here's how.
            </h2>
            <div className="mt-8 grid gap-4">
              <Formula
                n="01"
                title="Your edge is a number."
                formula="Edge per trade = (Win rate × Average win) − (Loss rate × Average loss) − Costs"
                example="Example (illustration only): Win 40% at ₹1,500, lose 60% at ₹800, costs ₹150 per trade →"
                worked="0.40 × 1,500 − 0.60 × 800 − 150 = −₹30 per trade."
                caption="Feels like a good system. Still loses money. You can only fix what you measure."
              />
              <Formula
                n="02"
                title="Position size is a formula, not a feeling."
                formula="Quantity = Money you can afford to lose on this trade ÷ Distance to stop-loss"
                example="Example: ₹5,000 risk ÷ ₹5 stop distance = 1,000 shares."
                caption="Same risk on every trade. No more one big loss wiping out ten wins."
              />
              <Formula
                n="03"
                title="A daily loss limit is a rule, not hope."
                formula="If today's loss ≥ maximum loss per day → no more trades today."
                caption="One bad morning stays one bad morning."
              />
            </div>
            <p className="mt-6 text-sm text-muted">
              All numbers are illustrations for learning, not results or recommendations.
            </p>
          </div>
        </section>

        <section className="bg-paper">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="max-w-3xl text-3xl font-semibold text-ink sm:text-4xl">
              The 7 conditions every trade must pass
            </h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-body">
              A trade is taken only when all 7 are true. If even one is false, there is
              no trade.
            </p>
            <ol className="mt-8 max-w-3xl border-t border-line">
              {CONDITIONS.map(([title, line], index) => (
                <li key={title} className="grid grid-cols-[2.5rem_1fr] gap-3 border-b border-line py-4">
                  <span className="font-mono text-sm font-medium text-accent">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <p className="text-base leading-relaxed text-body">
                    <span className="font-display font-semibold text-ink">{title}</span>
                    {" — "}
                    {line}
                  </p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="bg-ink text-paper">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="max-w-2xl text-3xl font-semibold text-paper sm:text-4xl">
              Rules you can see, not a black box.
            </h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-paper">
              This is the actual settings panel of the FMTS framework we teach from.
              Every condition and every risk limit is a setting you can see and change.
            </p>
            {SHOTS.length > 0 ? (
              <>
                <div className="mt-8 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 md:grid md:grid-cols-2 md:overflow-visible">
                  {SHOTS.map((shot) => (
                    <figure key={shot.caption} className="w-[85%] shrink-0 snap-start md:w-auto">
                      <button
                        type="button"
                        onClick={() => setOpenShot(shot)}
                        className="block w-full border border-edge bg-panel text-left"
                      >
                        <img
                          src={shot.src}
                          alt={shot.caption}
                          className={
                            shot.fit === "contain"
                              ? "h-auto w-full object-contain"
                              : "h-72 w-full object-cover object-top"
                          }
                          loading="lazy"
                        />
                      </button>
                      <figcaption className="mt-3 text-sm leading-relaxed text-paper-soft">
                        {shot.caption}
                      </figcaption>
                    </figure>
                  ))}
                </div>
                <p className="mt-6 text-sm text-paper-soft">
                  Settings shown for education. Not a recommendation to trade any security.
                </p>
              </>
            ) : null}
          </div>
        </section>

        <section className="bg-card">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="max-w-2xl text-3xl font-semibold text-ink sm:text-4xl">
              What happens in the 60 minutes
            </h2>
            <ol className="mt-8 max-w-3xl border-t border-line">
              {AGENDA.map(([when, what]) => (
                <li key={when} className="grid gap-1 border-b border-line py-4 sm:grid-cols-[8rem_1fr] sm:gap-4">
                  <span className="font-mono text-sm font-medium text-ink">{when}</span>
                  <span className="text-base text-body">{what}</span>
                </li>
              ))}
            </ol>
            <p className="mt-6 max-w-2xl text-base text-body">
              You also get the free 7 Conditions guide (PDF) as soon as you register.
            </p>
          </div>
        </section>

        <section className="bg-paper">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="text-3xl font-semibold text-ink sm:text-4xl">Who runs this</h2>
            <p className="mt-6 font-display text-xl font-semibold text-ink">
              MS · Founder, FiNARTHiS Academy
            </p>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-body">
              5+ years of active trading on NSE and MCX with a deep, data-driven
              understanding of how markets move. More than a decade of working
              experience as an engineer with MNCs — which is why everything here is
              built like an engineering spec: measured, tested, written down.
              NISM-certified.
            </p>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted">
              NISM certification is a qualification, not a SEBI registration. FiNARTHiS
              is not a SEBI-registered investment adviser or research analyst.
            </p>
          </div>
        </section>

        <section id="register" className="scroll-mt-6 bg-ink">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <div className="max-w-xl bg-card p-5 sm:p-8">
              {registered ? (
                <div>
                  <h2 id="success-title" tabIndex={-1} className="text-3xl font-semibold text-ink">
                    You're registered, {registered}.
                  </h2>
                  <div className="mt-6 grid gap-3">
                    {GUIDE_PDF_URL ? (
                      <a
                        href={GUIDE_PDF_URL}
                        target="_blank"
                        rel="noopener"
                        className="inline-flex min-h-12 w-full items-center justify-center bg-accent px-4 text-center text-base font-semibold text-ink"
                      >
                        Download the free 7 Conditions guide
                      </a>
                    ) : (
                      <p className="text-base leading-relaxed text-body">
                        Your guide will be sent on WhatsApp
                      </p>
                    )}
                    <a
                      className="inline-flex min-h-12 w-full items-center justify-center border-2 border-ink px-4 text-center text-base font-semibold text-ink"
                      {...linkProps(TELEGRAM_URL)}
                    >
                      Join the masterclass Telegram group
                    </a>
                  </div>
                  <p className="mt-4 text-sm leading-relaxed text-body">
                    The live link is posted in the Telegram group 30 minutes before your
                    session.
                  </p>
                </div>
              ) : (
                <form onSubmit={onSubmit} noValidate aria-busy={pending}>
                  <h2 className="text-3xl font-semibold text-ink">Reserve your free seat</h2>
                  <div className="mt-6 grid gap-5">
                    <Field id="name" label="Full name" error={errors.name}>
                      <input
                        id="name"
                        name="name"
                        type="text"
                        autoComplete="name"
                        autoCapitalize="words"
                        maxLength={160}
                        value={name}
                        onChange={(event) => setName(event.target.value)}
                        onBlur={() => setName((value) => value.trim())}
                        aria-invalid={errors.name ? true : undefined}
                        aria-describedby={errors.name ? "name-error" : undefined}
                        className={inputClass(Boolean(errors.name))}
                      />
                    </Field>

                    <Field id="phone" label="Contact number" error={errors.phone} hint="India +91">
                      <PhoneInput
                        id="phone"
                        name="phone"
                        value={phone}
                        error={Boolean(errors.phone)}
                        autoComplete="tel-national"
                        onChange={setPhone}
                      />
                    </Field>

                    <Field
                      id="whatsapp"
                      label="WhatsApp number, only if different from contact number"
                      error={errors.whatsapp}
                      optional
                    >
                      <PhoneInput
                        id="whatsapp"
                        name="whatsapp"
                        value={whatsapp}
                        error={Boolean(errors.whatsapp)}
                        autoComplete="tel"
                        onChange={setWhatsapp}
                      />
                    </Field>

                    <Field id="email" label="Email ID" error={errors.email}>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        inputMode="email"
                        autoComplete="email"
                        autoCapitalize="none"
                        spellCheck={false}
                        maxLength={254}
                        value={email}
                        onChange={(event) => setEmail(event.target.value)}
                        onBlur={() => setEmail((value) => value.trim())}
                        aria-invalid={errors.email ? true : undefined}
                        aria-describedby={errors.email ? "email-error" : undefined}
                        className={inputClass(Boolean(errors.email))}
                      />
                    </Field>

                    <fieldset
                      aria-invalid={errors.session ? true : undefined}
                      aria-describedby={errors.session ? "session-error" : undefined}
                    >
                      <legend className="mb-2 text-sm font-medium text-ink">
                        Session
                        <span aria-hidden="true"> *</span>
                        <span className="sr-only"> required</span>
                      </legend>
                      <div className="grid gap-2">
                        {SESSIONS.map((option, index) => {
                          const selected = session === option;
                          return (
                            <label
                              key={option}
                              className={`flex min-h-12 cursor-pointer items-center gap-3 border-2 px-3 ${selected ? "border-accent bg-paper" : "border-line bg-card"}`}
                            >
                              <input
                                id={index === 0 ? "session" : undefined}
                                type="radio"
                                name="session"
                                value={option}
                                checked={selected}
                                onChange={() => setSession(option)}
                              />
                              <span className="text-base text-body">{option}</span>
                            </label>
                          );
                        })}
                      </div>
                      {errors.session ? <ErrorText id="session-error" text={errors.session} /> : null}
                    </fieldset>

                    <div>
                      <label htmlFor="consent" className="flex min-h-11 cursor-pointer items-start gap-3">
                        <span className="flex h-11 w-11 shrink-0 items-center justify-center">
                          <input
                            id="consent"
                            name="consent"
                            type="checkbox"
                            checked={consent}
                            onChange={(event) => setConsent(event.target.checked)}
                            aria-invalid={errors.consent ? true : undefined}
                            aria-describedby={errors.consent ? "consent-error" : undefined}
                            className="size-6"
                          />
                        </span>
                        <span className="pt-2 text-sm leading-relaxed text-body">
                          I agree that FiNARTHiS Academy may contact me on WhatsApp, phone
                          and email about this masterclass and its courses. I can opt out
                          any time by replying STOP.
                        </span>
                      </label>
                      {errors.consent ? <ErrorText id="consent-error" text={errors.consent} /> : null}
                    </div>

                    <button
                      type="submit"
                      disabled={pending}
                      aria-busy={pending}
                      className="inline-flex min-h-12 w-full items-center justify-center bg-accent px-4 text-base font-semibold text-ink disabled:opacity-60"
                    >
                      Register free
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </section>

        <section className="bg-paper">
          <div className="mx-auto max-w-5xl px-5 py-16 sm:px-8 sm:py-24">
            <h2 className="text-3xl font-semibold text-ink sm:text-4xl">FAQ</h2>
            <div className="mt-6 max-w-3xl border-t border-line">
              {FAQ.map(([question, answer]) => (
                <details key={question} className="border-b border-line">
                  <summary className="flex min-h-12 items-center justify-between gap-4 py-3">
                    <h3 className="text-base font-semibold text-ink">{question}</h3>
                    <ChevronDown className="chevron size-5 shrink-0 text-ink" aria-hidden="true" />
                  </summary>
                  <p className="pb-4 text-base leading-relaxed text-body">{answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-ink pb-28 text-paper md:pb-16">
        <div className="mx-auto max-w-5xl px-5 py-12 sm:px-8">
          <p className="font-display text-lg font-semibold">FiNARTHiS Academy</p>
          <p className="mt-3">
            <a
              href="mailto:finarthis@gmail.com"
              className="inline-flex min-h-11 items-center underline decoration-accent underline-offset-4"
            >
              finarthis@gmail.com
            </a>
          </p>
          <p>
            <a
              href="https://wa.me/918980908278"
              className="inline-flex min-h-11 items-center underline decoration-accent underline-offset-4"
              target="_blank"
              rel="noopener noreferrer"
            >
              +91 8980908278
            </a>
          </p>
          <p className="mt-6 max-w-3xl text-xs leading-relaxed text-paper-soft">
            Educational content only. Not investment advice. FiNARTHiS Academy does not
            provide investment advice, research recommendations, trading signals or any
            service requiring SEBI registration. FiNARTHiS and its founder are not
            registered with SEBI as an investment adviser or research analyst. All market
            examples use price data at least 30 days old. No claims are made about past
            or future performance. Most retail traders in intraday and derivatives
            segments lose money.
          </p>
          <p className="mt-4">
            <a
              className="inline-flex min-h-11 items-center text-sm underline decoration-accent underline-offset-4"
              {...linkProps(PRIVACY_URL)}
            >
              Privacy
            </a>
          </p>
        </div>
      </footer>

      <div
        className={`mobile-cta fixed inset-x-0 bottom-0 z-40 border-t border-edge bg-ink p-3 transition-transform duration-200 md:hidden ${showBar ? "translate-y-0" : "pointer-events-none translate-y-full"}`}
      >
        <a
          href="#register"
          className="inline-flex min-h-12 w-full items-center justify-center bg-accent px-4 text-base font-semibold text-ink"
        >
          Register free
        </a>
      </div>

      {openShot ? (
        <div
          className="fixed inset-0 z-50 flex flex-col bg-ink p-4"
          role="dialog"
          aria-modal="true"
          aria-label={openShot.caption}
        >
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setOpenShot(null)}
              className="inline-flex min-h-11 items-center bg-accent px-4 text-sm font-semibold text-ink"
            >
              Close
            </button>
          </div>
          <button
            type="button"
            className="mt-3 flex min-h-0 flex-1 items-center justify-center"
            onClick={() => setOpenShot(null)}
            aria-label="Close settings image"
          >
            <img
              src={openShot.src}
              alt={openShot.caption}
              className="max-h-full max-w-full object-contain"
            />
          </button>
          <p className="pt-3 text-sm text-paper-soft">{openShot.caption}</p>
        </div>
      ) : null}
    </>
  );
}

function TradeFilter() {
  return (
    <div
      className="border border-edge bg-card p-4 text-ink sm:p-5"
      aria-label="A signal passes seven conditions. If one fails, there is no trade. If all pass, the trade is allowed."
    >
      <p className="font-mono text-xs font-medium tracking-widest text-muted uppercase">Signal</p>
      <ol className="mt-3 grid gap-2">
        {FILTER_CONDITIONS.map((condition, index) => (
          <li key={condition.name}>
            <div className="flex items-center justify-between gap-3 border border-line px-3 py-2">
              <span className="text-sm text-body">
                <span className="font-mono text-muted">{index + 1}</span> {condition.name}
              </span>
              {condition.pass ? (
                <svg viewBox="0 0 20 20" className="size-5 shrink-0 text-accent" aria-hidden="true">
                  <path d="M4 10.5 8 14.5 16 6" fill="none" stroke="currentColor" strokeWidth="2" />
                </svg>
              ) : (
                <svg viewBox="0 0 20 20" className="size-5 shrink-0 text-fail" aria-hidden="true">
                  <path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor" strokeWidth="2" />
                </svg>
              )}
            </div>
            {condition.pass ? null : (
              <p className="mt-2 ml-6 border border-line bg-paper px-3 py-2 text-sm text-muted">
                No trade
              </p>
            )}
          </li>
        ))}
      </ol>
      <p className="mt-3 bg-accent px-3 py-3 text-center font-display text-base font-semibold text-ink">
        Trade allowed
      </p>
    </div>
  );
}

function Pain({ icon, text }: { icon: ReactNode; text: string }) {
  return (
    <li className="flex items-center gap-3 border border-line bg-card p-4 text-base text-ink">
      <span className="text-ink">{icon}</span>
      {text}
    </li>
  );
}

function Formula({
  n,
  title,
  formula,
  example,
  worked,
  caption,
}: {
  n: string;
  title: string;
  formula: string;
  example?: string;
  worked?: string;
  caption: string;
}) {
  return (
    <article className="border border-line p-5">
      <p className="font-mono text-sm font-medium text-accent">{n}</p>
      <h3 className="mt-2 text-xl font-semibold text-ink">{title}</h3>
      <p className="mt-4 font-mono text-sm leading-relaxed text-ink sm:text-base">{formula}</p>
      {example ? <p className="mt-4 text-base leading-relaxed text-body">{example}</p> : null}
      {worked ? <p className="mt-2 font-mono text-sm leading-relaxed text-ink sm:text-base">{worked}</p> : null}
      <p className="mt-4 text-base leading-relaxed text-body">{caption}</p>
    </article>
  );
}

function inputClass(invalid: boolean) {
  return `min-h-12 w-full border bg-card px-3 text-base text-body ${invalid ? "border-ink" : "border-line"}`;
}

function ErrorText({ id, text }: { id: string; text: string }) {
  return (
    <p id={id} role="alert" className="mt-2 text-sm font-medium text-ink">
      <span className="sr-only">Error: </span>
      {text}
    </p>
  );
}

function Field({
  id,
  label,
  error,
  optional,
  hint,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  optional?: boolean;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium text-ink">
        {label}
        {optional ? null : (
          <>
            <span aria-hidden="true"> *</span>
            <span className="sr-only"> required{hint ? `, ${hint}` : ""}</span>
          </>
        )}
      </label>
      {children}
      {error ? <ErrorText id={`${id}-error`} text={error} /> : null}
    </div>
  );
}

function PhoneInput({
  id,
  name,
  value,
  error,
  autoComplete,
  onChange,
}: {
  id: string;
  name: string;
  value: string;
  error: boolean;
  autoComplete: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className={`phone-field flex min-h-12 border bg-card ${error ? "border-ink" : "border-line"}`}>
      <span className="flex items-center border-r border-line px-3 text-base font-medium text-ink" aria-hidden="true">
        +91
      </span>
      <input
        id={id}
        name={name}
        type="tel"
        inputMode="numeric"
        autoComplete={autoComplete}
        autoCapitalize="none"
        spellCheck={false}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        onBlur={() => onChange(nationalDigits(value))}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-error` : undefined}
        className="min-h-12 w-full bg-transparent px-3 text-base text-body"
      />
    </div>
  );
}
